
def f3(a,b):
    c=a/b
    return c