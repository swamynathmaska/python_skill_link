def f2(a,b):
    c=a*b
    return c