def f1(a,b):
    c=a+b
    return c