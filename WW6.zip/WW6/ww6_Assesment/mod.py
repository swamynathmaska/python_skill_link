def f1(a,b):
    return a+b
def f2(a,b):
    return a*b
def f3(a,b):
    return a/b