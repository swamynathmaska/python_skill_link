def fun1(radius):
    area=(3.14)*radius*radius
    return area
def fun2(radius):
    circumference=2*(3.14)*radius
    return circumference
def fun3(radius):
    dia=2*radius
    return dia

    
    