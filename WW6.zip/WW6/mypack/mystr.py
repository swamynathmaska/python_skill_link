''' This module implements basic string operations '''
print("\n ::: welcome to mystr module :::")

def str_len(s):
    return len(s)
def str_cmp(s1,s2):
    return s1 ==s2
def str_cat(s1,s2):
    return s1+s2