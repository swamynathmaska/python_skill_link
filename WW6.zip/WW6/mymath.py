'''this module implement basic operations of mathematical'''
print('\n :::welcome to the mymathmadule :::')
def add(x,y):
    return x+y
def sub(x,y):
    return x-y
def mult(x,y):
    return x*y
def div(x,y):
    return x/y